<!DOCTYPE html>
<html>
  <head>
    <title>Powered By Paketo Buildpacks</title>
  </head>
  <body>
<?php
echo '<img style="display: block; margin-left: auto; margin-right: auto; width: 50%;" src="https://img.zcool.cn/community/012e3b5954ee3da8012193a387c830.png?x-oss-process=image/auto-orient,1/resize,m_lfit,w_1280,limit_1/sharpen,100/quality,q_100/format,webp"></img>';
?>
  </body>
</html>
