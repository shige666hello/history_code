# Hello World

快速部署一个 Nodejs 的 Hello World 函数到函数计算（FC）。

- [HelloWorld 示例代码](https://github.com/Qihoo360/fc-templates/tree/feature/fc-app-test/examples/custom-runtime/http-function/fc-node/node18/hello-world-df/src)

## 前期准备

使用该项目，您需要有开通以下服务并拥有对应权限：

| 服务/业务 |
| --------- |
| 函数计算  |

## 部署 & 体验

- 通过 [Serverless 应用中心](https://console.zyun.qihoo.net/fc), 部署该应用。

## 开发者社区

### 360智汇云函数计算FC

- 交流群
![tuitui](https://github.com/Qihoo360/fc-templates/blob/feature/fc-app-test/assets/tuitui-feedback-group.gif?raw=true)

### Serverless Devs

- Serverless Devs 项目：<https://www.github.com/serverless-devs/serverless-devs>
- Serverless Devs 文档：<https://docs.serverless-devs.com>
- Serverless Devs 钉钉交流群：33947367
